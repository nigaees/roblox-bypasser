import requests
import os
import time
import colorama
from colorama import Fore, Back, Style
colorama.init()

print(r'''                                                   
       
   l^____
   l     \
   l      l
   l      l    
   l      l /\   /\
   l       l  \ /  l
   l     / l   l   l
   l____>  l       l  (mass uploader)
                                                                                                
''')

time.sleep(5)
input(
    " [Discord Mass] Press enter to open menu "
)

def menu():
    print(" ")
    print(Fore.GREEN + ' [1] Mass dm ')
    print(" ------------ ")
    print(" [2] not working ")
    print(" ---------------- ")
    print(" [3] not working ")
    print(" ---------------- ")

menu()
option = int(input(" Choose your option: "))

while option != 1:
    if option == 1:
        #do option 1 stuff
        print("Option 1 has been called.")
    elif option == 2:
        #option 2 stuff
        print("Option 2 has been called.")
    else:
        print("Invalid option.")

def main():
    pid = os.getpid()
    print(" ")
    print( " Discord API : " ,pid)
    print(" ---------------------- ")
    print(" Mass uploading! ")



if __name__ == "__main__":
    main()



payload = {
    'content': "@everyone fuck yall"
}

header = {
    'authorization': 'paste here id of message chat'
}

for i in range (1000):
    r = requests.post('and here api', data=payload, headers=header)
input()

## only using in web discord, and app discord
## made by pryncx.
