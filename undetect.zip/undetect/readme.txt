
 free undetected discord spammer
  (but its too slow like 1-3 seconds)
 if not working say to me [pryncexes]
good luck to use and have a good day!

UPDATE : [1.4.6]
- added menu with mass dm
- changed ui
- added nigga XD