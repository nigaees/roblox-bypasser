
 free undetected discord spammer
  (but its too slow like 1-3 seconds)
 if not working say to me [pryncexes]
good luck to use and have a good day!

UPDATE : Updated Version
- updated dm
- now you can spam your friends
+ ip logger will see who skiding my code fr fr

# WARNING! USE DM SPAMMER FOR UR RISK ITS BANNABLE.