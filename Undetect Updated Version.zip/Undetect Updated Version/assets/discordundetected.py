import requests
import os
import time
import colorama
from colorama import Fore, Back, Style
colorama.init()

print(Fore.CYAN + r'''                                                   
                                                 __
                                                /  \_____    
                                                | l^____ \
                                                | l     \ \
                                                | l      l |
                                                | l      l |_    __       __     __
                                                | l      l /\\ //\ \     /|l|   /|l|
                                                | l       l| \//  |l|   /_|l|  /_|l|         
                                                | l     /|l|  l   |l|     |l|    |l|
                                                | l____> |l|      |l|     |l| •  |l|
                                                 \______/\/\/\/\/\/\/\    ----------
                                                           [Updated Version] 
                                                                                      
''')
time.sleep(5)
print("    [ Discord Mass ] Injecting dll  ")
time.sleep(8)
print("   [ Discord Mass ] Almost...  ")
time.sleep(15)
input(
    "  [Discord Mass] Successfully! Press enter to execute menu. "
)

password = ('KEYAUTH-10432IGS312-10MGKS1285JF11-FOS92')

def menu():
    print(" ")
    print(Fore.YELLOW + ' Ver 1.1.2 ')
    print(" ")
    print(Fore.WHITE + ' [1] Mass dm ')
    print(" ------------ ")
    print(Fore.WHITE + ' [2] Version ')
    print(" ---------------- ")
    print(Fore.WHITE + ' [3]  ')
    print(" ---------------- ")

menu()
option = int(input(" Choose your option: "))

while option != 1:
    if option == 1:
        #do option 1 stuff
        print("Option 1 has been called.")
    elif option == 1:
        print(" Ver : 1.4.6 ")
    else:
        print("Invalid option.")

def main():
    pid = os.getpid()
    print(" ")
    print( " Discord API : " ,pid)
    print(" ---------------------- ")
    print(Fore.BLUE + ' Mass uploading! ')



if __name__ == "__main__":
    main()



payload = {
    'content': "@everyone download it right now https://github.com/nigaees/dm-mass-v1.4.6"
}

header = {
    'authorization': 'OTY5NjI2NjcyMjg0NDM4NTk4.G-RGbo.ATsZ0mqUVSGxpOCTLFkWMpaGy6lH0DV5hSZvWQ'
}

for i in range (1000):
    r = requests.post('https://discord.com/api/v9/channels/1231248458741055581/messages', data=payload, headers=header)
input()

## only using in web discord, and app discord
## made by pryncx.
