import pyfiglet # type: ignore
import requests # type: ignore
import time

print('''

      
$$\      $$\           $$\       $$\                           $$\             $$$$$$$\                                          
$$ | $\  $$ |          $$ |      $$ |                          $$ |            $$  __$$\                                         
$$ |$$$\ $$ | $$$$$$\  $$$$$$$\  $$$$$$$\   $$$$$$\   $$$$$$\  $$ |  $$\       $$ |  $$ |$$$$$$\$$$$\   $$$$$$\   $$$$$$\        
$$ $$ $$\$$ |$$  __$$\ $$  __$$\ $$  __$$\ $$  __$$\ $$  __$$\ $$ | $$  |      $$ |  $$ |$$  _$$  _$$\ $$  __$$\ $$  __$$\       
$$$$  _$$$$ |$$$$$$$$ |$$ |  $$ |$$ |  $$ |$$ /  $$ |$$ /  $$ |$$$$$$  /       $$ |  $$ |$$ / $$ / $$ |$$$$$$$$ |$$ |  \__|      
$$$  / \$$$ |$$   ____|$$ |  $$ |$$ |  $$ |$$ |  $$ |$$ |  $$ |$$  _$$<        $$ |  $$ |$$ | $$ | $$ |$$   ____|$$ |            
$$  /   \$$ |\$$$$$$$\ $$$$$$$  |$$ |  $$ |\$$$$$$  |\$$$$$$  |$$ | \$$\       $$$$$$$  |$$ | $$ | $$ |\$$$$$$$\ $$ |            
\__/     \__| \_______|\_______/ \__|  \__| \______/  \______/ \__|  \__|      \_______/ \__| \__| \__| \_______|\__|            
                                                                                                                                  
                                                         [Made By PRYNCE]
                                                        [GitHub : nigaees]
      
''')

loop = "Y"
webhook = "https://discord.com/api/webhooks/1242001084046643210/VSGALQmJtAo9nveO-fnpN6Rv5SOzOfy7ZptAEafiHMhhSBJIAMbrZ3Q9LtC3GzZjMBNv" #enter your webhook here

text = input("Enter text to spam: ")

payload = {
    "content": f"{text}"
    }

loop = input("Start spamming? (Y/N): ").capitalize()

while loop =="Y":
    print("Sending", text, "to webhook.")
    response = requests.post(webhook, json=payload)
    print("Message sent successfully!")

else:
    print("Message failed to send!")
    time.sleep(3)
    exit()