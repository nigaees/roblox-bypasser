## About

This repository contains a straightforward program designed for batch projects, offering an enhanced GUI Buttons function.

- Refer to the usage example provided.
- Comments within the "Button.bat" file provide insights into the program's functionality.

## Screenshot

![](https://raw.githubusercontent.com/Psi505/Batch-GUI-Button/main/Screenshot.png)
